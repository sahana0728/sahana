package www.javamaven.com;

import java.io.*;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        File f = new File("a.txt");
        System.out.println("f = " + f);
        System.out.println( "Hello World!" );
        System.out.println( "Hello World!" );
        System.out.println( "zhc" );
        System.out.println( "yq" );
        System.out.println( "yq" );
        System.out.println( "yq" );
    }
}
